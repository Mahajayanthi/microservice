package com.codedecode.microservices.VaccinationCenter.Entity;

import java.util.Optional;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="vaccination")
public class VaccinationCenter {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String centerName;
	
	private String centerAddress;

	public Optional<VaccinationCenter> findVaccinationCenterById(Integer id2) {
		// TODO Auto-generated method stub
		return null;
	}

//	public boolean isNotPresent() {
//		// TODO Auto-generated method stub
//		return false;
//	}

	
	

}
